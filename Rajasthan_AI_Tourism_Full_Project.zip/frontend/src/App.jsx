
import React,{useState} from "react";
import axios from "axios";

export default function App(){

const [msg,setMsg]=useState("");
const [ans,setAns]=useState("");

async function send(){
let r=await axios.post("http://localhost:5000/chat",
{message:msg});
setAns(r.data.answer);
}

return <div>
<h1>Rajasthan AI Tourism</h1>

<input onChange={e=>setMsg(e.target.value)}
placeholder="Ask about Rajasthan"/>

<button onClick={send}>Ask</button>

<h3>{ans}</h3>

</div>
}
