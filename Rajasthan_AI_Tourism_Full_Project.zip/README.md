
# Rajasthan AI Tourism

Full stack startup MVP.

Stack:
- React
- Node.js
- Express
- MongoDB

Run backend:
cd backend
npm install
npm start

Run frontend:
cd frontend
npm install
npm start
