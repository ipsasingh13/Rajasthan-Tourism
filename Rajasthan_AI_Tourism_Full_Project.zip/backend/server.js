
const express=require("express");
const mongoose=require("mongoose");
const cors=require("cors");
require("dotenv").config();

const app=express();
app.use(cors());
app.use(express.json());

mongoose.connect(process.env.MONGO_URL)
.then(()=>console.log("MongoDB connected"));

app.post("/chat",(req,res)=>{
 let q=req.body.message.toLowerCase();
 let answer="I can help with Rajasthan tourism.";

 if(q.includes("places"))
 answer="Jaipur, Udaipur, Jaisalmer, Jodhpur, Mount Abu";

 if(q.includes("temple"))
 answer="Brahma Temple, Karni Mata Temple, Eklingji Temple";

 if(q.includes("20000"))
 answer="Budget plan: Jaipur + Udaipur + Jodhpur.";

 res.json({answer});
});

app.listen(5000,()=>console.log("Server 5000"));
