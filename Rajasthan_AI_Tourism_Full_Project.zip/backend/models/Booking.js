
const mongoose=require("mongoose");

module.exports=mongoose.model("Booking",
new mongoose.Schema({
user:String,
place:String,
date:String,
persons:Number
}));
