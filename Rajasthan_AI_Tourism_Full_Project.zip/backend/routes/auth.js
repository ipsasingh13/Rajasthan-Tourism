
const router=require("express").Router();
const User=require("../models/User");

router.post("/register",async(req,res)=>{
let u=new User(req.body);
await u.save();
res.json({message:"Created"});
});

router.post("/login",async(req,res)=>{
let u=await User.findOne(req.body);
res.json({success:!!u});
});

module.exports=router;
