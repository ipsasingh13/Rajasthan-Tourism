export default function Home(){
return <div>
<h1>Discover Royal Rajasthan</h1>
<p>Forts, temples, villages, culture and AI travel planning.</p>
</div>
}
