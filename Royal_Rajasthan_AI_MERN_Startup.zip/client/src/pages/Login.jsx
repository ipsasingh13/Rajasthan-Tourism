export default function Login(){
return <div>
<h1>Royal Rajasthan AI Login</h1>
<input placeholder='Email'/>
<input placeholder='Password'/>
<button>Login</button>
</div>
}
