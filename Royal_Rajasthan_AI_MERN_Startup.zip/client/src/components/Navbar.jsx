export default function Navbar(){
return <nav>🏰 Royal Rajasthan AI</nav>
}
