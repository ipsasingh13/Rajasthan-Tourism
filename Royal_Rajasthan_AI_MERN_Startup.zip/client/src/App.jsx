import {Routes,Route} from 'react-router-dom';
import Home from './pages/Home';
import Login from './pages/Login';

export default function App(){
return <Routes>
<Route path="/" element={<Login/>}/>
<Route path="/home" element={<Home/>}/>
</Routes>
}
