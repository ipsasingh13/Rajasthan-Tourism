# Royal Rajasthan AI

MERN Stack Tourism Startup MVP

Features:
- Login/Register
- Rajasthan Explorer
- AI Trip Planner
- Budget Planner
- AI Chatbot
- Dashboard
- Hotel/Package modules

Run:
server: npm install && npm start
client: npm install && npm run dev
